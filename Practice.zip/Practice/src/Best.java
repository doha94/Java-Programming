/*이클립스를 이용하여 다음과 같이 화면에 "학기가 시작되었어요!", "이번 학기에는 자바를 열심히 공부해 최고의  Software개발자가 될 거에요~~" 를 출력하는 자바 프로그램을 작성하라. 이클립스를 사용할 때 작업공간(workspace)은 C:\Temp 로 하고, 프로젝트 이름은 1-2로 하고, 클래스 이름은Best로 하라.*/
public class Best {
    public static void main(String[] args) {
        // 메시지 출력
        System.out.println("학기가 시작되었어요!");
        System.out.println("이번 학기에는 자바를 열심히 공부해 최고의 Software 개발자가 될 거에요~~");
    }
}
