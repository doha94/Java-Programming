/*이클립스를 이용하여 다음과 같이 "자바는 처음이죠?". "Welcome to Java World~~"를 출력하는 자바 프로그램을 작성하라. 이클립스를 사용할 때 작업 공간(workspace)은 C:\Temp로 하고, 프로젝트 이름은 1-1로 하고, 클래스 이름은 Welcome으로 하라.*/

public class Welcome {
    public static void main(String[] args) {
        // 메시지 출력
        System.out.println("자바는 처음이죠?");
        System.out.println("Welcome to Java World~~");
    }
}