package Pra2to2;

public class WhatCode {
	public static void main() {
		String sum = "이 코드는 1부터 50까지의 숫자 중 3씩 증가하는 값들의 합을 계산합니다. 즉, 1, 4, 7, 10, ..., 49까지의 숫자들의 합을 계산합니다.\\r\\n\"\r\n"
				+ "				+ \"\\r\\n\"\r\n"
				+ "				+ \"i는 1부터 시작하고, 매 반복마다 3씩 증가합니다. 조건문 if(i > 50)가 참이 되면 반복문이 종료됩니다.\\r\\n\"\r\n"
				+ "				+ \"\\r\\n\"\r\n"
				+ "				+ \"실행 결과는 1, 4, 7, 10, ..., 49까지의 합이므로 출력값은 425입니다.";
		
		System.out.println(sum);
	}

}
