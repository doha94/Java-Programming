package Pra2to1;

public class WhatCode {
	public static void main() {
		String sum = "이 코드는 배열 n에서 양수이면서 4의 배수인 값을 출력하는 코드입니다. 배열을 순회하면서 각 값이 0보다 크고 4의 배수인지 확인한 후 조건을 만족하는 값만 출력합니다.\r\n"
				+ "\r\n"
				+ "n[] = {1, -2, 6, 20, 5, 72, -16, 256}에서 양수이면서 4의 배수인 값은 72와 256입니다.\r\n"
				+ "\r\n"
				+ "실행 결과: 72 256";
		
		System.out.println(sum);
	}

}